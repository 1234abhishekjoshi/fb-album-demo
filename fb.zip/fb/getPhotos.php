<?php
session_start();
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/vendor/autoload.php';
$session = $_SESSION['fb_access_token'];
$id = $_POST['id'];
$fb = new Facebook\Facebook([
  'app_id' => '1644064042312581', // Replace {app-id} with your app id
  'app_secret' => 'be8204e73634fb5c6410ffb0474e33d3',
  'default_graph_version' => 'v2.9',
  ]);

$photos = $fb->get("/".$id."/photos?fields=picture", $session)->getGraphEdge()->asArray();
echo json_encode(array('status' => 1 , 'data' => $photos));
?>