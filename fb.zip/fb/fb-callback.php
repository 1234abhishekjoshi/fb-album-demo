<?php 
session_start();
require_once __DIR__ . '/vendor/autoload.php';
$fb = new Facebook\Facebook([
  'app_id' => '1644064042312581', // Replace {app-id} with your app id
  'app_secret' => 'be8204e73634fb5c6410ffb0474e33d3',
  'default_graph_version' => 'v2.9',
  ]);

$helper = $fb->getRedirectLoginHelper();
if (isset($_GET['state'])) {
    $helper->getPersistentDataHandler()->set('state', $_GET['state']);
}
try {
  $accessToken = $helper->getAccessToken();
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

if (! isset($accessToken)) {
  if ($helper->getError()) {
    header('HTTP/1.0 401 Unauthorized');
    echo "Error: " . $helper->getError() . "\n";
    echo "Error Code: " . $helper->getErrorCode() . "\n";
    echo "Error Reason: " . $helper->getErrorReason() . "\n";
    echo "Error Description: " . $helper->getErrorDescription() . "\n";
  } else {
    header('HTTP/1.0 400 Bad Request');
    echo 'Bad request';
  }
  exit;
}

// The OAuth 2.0 client handler helps us manage access tokens
$oAuth2Client = $fb->getOAuth2Client();


$_SESSION['fb_access_token'] = (string) $accessToken;
$session = $_SESSION['fb_access_token'];
try {
    // Returns a `Facebook\FacebookResponse` object
    $response= $fb->get('/me?fields=id,name,first_name,last_name,gender,link,birthday,location,picture', $session);
} catch(Facebook\Exceptions\FacebookResponseException $e) {
    echo 'Graph returned an error: ' . $e->getMessage();
    exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
    exit;
}

$user= $response->getGraphUser();

$albums = $fb->get('/me/albums', $session)->getGraphEdge()->asArray();




?>
<!DOCTYPE HTML>
<html lang="en-US">
    

<head>

        <meta charset="UTF-8">
        <title>Beoro Admin Template v1.2</title>
        <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
        <link rel="icon" type="image/ico" href="favicon.ico">
        
    <!-- common stylesheets-->
        <!-- bootstrap framework css -->
            <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
            <link rel="stylesheet" href="bootstrap/css/bootstrap-responsive.min.css">
        <!-- iconSweet2 icon pack (16x16) -->
            <link rel="stylesheet" href="img/icsw2_16/icsw2_16.css">
        <!-- splashy icon pack -->
            <link rel="stylesheet" href="img/splashy/splashy.css">
        <!-- flag icons -->
            <link rel="stylesheet" href="img/flags/flags.css">
        <!-- power tooltips -->
            <link rel="stylesheet" href="js/lib/powertip/jquery.powertip.css">
        <!-- google web fonts -->
            <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Abel">
            <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300">

    <!-- aditional stylesheets -->


        <!-- main stylesheet -->
            <link rel="stylesheet" href="css/beoro.css">
			
            <link rel="stylesheet" href="css/jquery.bxslider.css">
        <!--[if lte IE 8]><link rel="stylesheet" href="css/ie8.css"><![endif]-->
        <!--[if IE 9]><link rel="stylesheet" href="css/ie9.css"><![endif]-->
            
        <!--[if lt IE 9]>
            <script src="js/ie/html5shiv.min.js"></script>
            <script src="js/ie/respond.min.js"></script>
            <script src="js/lib/flot-charts/excanvas.min.js"></script>
        <![endif]-->

    </head>
    <body class="bg_d">
    <!-- main wrapper (without footer) -->    
        <div class="main-wrapper">
        <!-- top bar -->
            <div class="navbar navbar-fixed-top">
                <div class="navbar-inner">
                    <div class="container">
                        
                        <div id="fade-menu" class="pull-left">
                                                    </div>
                    </div>
                </div>
            </div>

        <!-- header -->
            <header>
                <div class="container">
                    <div class="row">
                        <div class="span3">
                            <div class="main-logo"><a href="index28ad.html?page=dashboard"><img src="img/beoro_logo.jpg" alt="Beoro Admin"></a></div>
                        </div>
                        <div class="span5">
                            
                        </div>
                        <div class="span4">
                            <div class="user-box-inner">
                                    <img src="<?php echo $user['picture']['url'];?>" alt="" class="user-avatar img-avatar">
                                    <div class="user-info">
                                        Welcome, <strong><?php echo $user['name']; ?></strong>
                                        
                                    </div>
                                </div>
                            

                        </div>
                    </div>
                </div>
            </header>

        <!-- breadcrumbs -->
            <div class="container">
                <ul id="breadcrumbs">
                    <li><a href="javascript:void(0)"><i class="icon-home"></i></a></li>
                    
                </ul>
            </div>
            
        <!-- main content -->
            <div class="container">
                <div class="row-fluid">
                    <div class="span12">
                        <div class="w-box w-box-blue">
                            <div class="w-box-header">albums</div>
                            <div class="w-box-content cnt_a">
                                <div id="large_grid" class="wmk_grid">
                                    <ul>
                                        
                                    
								<?php
								
								foreach($albums as $k => $album)
{
    
      $photos = $fb->get("/".$album['id']."/photos?fields=picture", $session)->getGraphEdge()->asArray();
	 
	  echo '<a onclick="showSlider('.$album['id'].')" style="cursor:pointer;"><div class="span3"><i class="splashy-folder_classic"></i><p>'.$album['name'].'</p></div></a>';
	  
}
								?>
								</ul>
                                </div>
                                 
								<div id="photo" align="center">
								</div>
								
                            </div>
                        </div>
                    </div>
                </div>
                
                
            </div>
            <div class="footer_space"></div>
        </div> 

    <!-- footer --> 
        <footer>
            <div class="container">
                <div class="row">
                    <div class="span5">
                        <div>&copy; Your Company 2012</div>
                    </div>
                    <div class="span7">
                        <ul class="unstyled">
                            <li><a href="#">First link</a></li>
                            <li>&middot;</li>
                            <li><a href="#">Second link</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        
    <!-- Common JS -->
        <!-- jQuery framework -->
            <script src="js/jquery.min.js"></script>
            <script src="js/jquery-migrate.js"></script>
        <!-- bootstrap Framework plugins -->
            <script src="bootstrap/js/bootstrap.min.js"></script>
        <!-- top menu -->
            <script src="js/jquery.fademenu.js"></script>
        <!-- top mobile menu -->
            <script src="js/selectnav.min.js"></script>
        <!-- actual width/height of hidden DOM elements -->
            <script src="js/jquery.actual.min.js"></script>
        <!-- jquery easing animations -->
            <script src="js/jquery.easing.1.3.min.js"></script>
        <!-- power tooltips -->
            <script src="js/lib/powertip/jquery.powertip-1.1.0.min.js"></script>
        
			
			<script src="js/jquery.bxslider.js"></script>
			            
<script>
  $(document).ready(function(){
  $('.bxslider').bxSlider({
	  pager : false
  });
});
function showSlider(id){
	$.ajax({
	    type : "POST",
        url : "getPhotos.php",
        data : {
			id : id
		},
        dataType : "JSON",
        success : function(data){
			if(data.status == 1){
				var photo = '<ul class="bxslider">';
				$.each(data.data,function(i,val){
					console.log(val);
					photo+="<li><img src="+val['picture']+" style='margin:auto;width:150px;height:130px;'/></li>";
				});
				$('#photo').html('');
				$('#photo').append(photo);
				
				$('.bxslider').bxSlider({
					  pager : false
				  });
			}
		}		
	});
	
}	
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-65387713-1', 'auto');
  ga('send', 'pageview');

</script>
<style type="text/css">
.bx-wrapper{
	max-width:25% !important;
}
</style>
    </body>


</html>